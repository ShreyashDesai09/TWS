#!/bin/bash

echo "THIS IS AN INTRODUCTION SCESSION"


a=10
b="ten"

echo "$a = $b"

d=$(date(%Y-%m-%d))
echo "Todays Date $d"
