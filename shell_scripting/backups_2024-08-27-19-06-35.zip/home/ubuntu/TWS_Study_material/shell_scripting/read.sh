#!/bin/bash

echo "READ AND ARGUMENTS"

name="Shreyash"

echo "MY NAME IS $name"

read -p "SURNAME:" sname

echo "SURNAME IS $sname"

echo "ROLLNUMBER IS $1"


